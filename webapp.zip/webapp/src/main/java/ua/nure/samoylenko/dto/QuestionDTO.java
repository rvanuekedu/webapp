package ua.nure.samoylenko.dto;

public class QuestionDTO {
	
	private String qText;
	
	private Integer testId;

	public String getqText() {
		return qText;
	}

	public void setqText(String qText) {
		this.qText = qText;
	}

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}
	
}
