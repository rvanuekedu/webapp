package ua.nure.samoylenko.dto;

public class TestChangeComplexityDTO {

	private Integer testId;
	
	private String complexity;

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	
}
