package ua.nure.samoylenko.utils;

public class StringConstants {
    private StringConstants(){
        // TODO: 04.03.2019 messasage
        throw new UnsupportedOperationException();
    }
}
