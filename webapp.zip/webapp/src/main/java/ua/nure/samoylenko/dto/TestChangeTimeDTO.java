package ua.nure.samoylenko.dto;

public class TestChangeTimeDTO {
	
	private Integer testId;
	
	private Integer testTime;

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public Integer getTestTime() {
		return testTime;
	}

	public void setTestTime(Integer testTime) {
		this.testTime = testTime;
	}
	
}
