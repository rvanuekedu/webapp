package ua.nure.samoylenko.entities;

public class Question {

	private Integer questionId;

	private String questionText;
	
	private Integer testId;

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	@Override
	public String toString() {
		return "Question{" +
				"questionId=" + questionId +
				", questionText='" + questionText + '\'' +
				", testId=" + testId +
				'}';
	}
}
